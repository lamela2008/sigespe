<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<title> 
			<?php $__env->startSection('title'); ?> 
			<?php echo $__env->yieldSection(); ?> 
		</title>

		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- Bootstrap 3.0: Latest compiled and minified CSS -->
		<!-- <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css"> -->
		<link rel="stylesheet" href="<?php echo e(asset('packages/rydurham/sentinel/css/bootstrap.min.css')); ?>">

		<!-- Optional theme -->
		<!-- <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-theme.min.css"> -->
		<link rel="stylesheet" href="<?php echo e(asset('packages/rydurham/sentinel/css/bootstrap-theme.min.css')); ?>">

		<style>
		<?php $__env->startSection('styles'); ?>
			body {
				padding-top: 60px;
			}
		<?php echo $__env->yieldSection(); ?>
		</style>

		<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
		<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

	
	</head>

	<body>
		

		<!-- Navbar -->
		<div class="navbar navbar-inverse navbar-fixed-top">
	      <div class="container">
	        <div class="navbar-header">
	          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	          </button>
	          <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Sentinel</a>
	        </div>
	        <div class="collapse navbar-collapse">
	          <ul class="nav navbar-nav">
				<?php if(Sentry::check() && Sentry::getUser()->hasAccess('admin')): ?>
					<li <?php echo (Request::is('users*') ? 'class="active"' : ''); ?>><a href="<?php echo e(action('\\Sentinel\Controllers\UserController@index')); ?>">Users</a></span></li>
					<li <?php echo (Request::is('groups*') ? 'class="active"' : ''); ?>><a href="<?php echo e(action('\\Sentinel\Controllers\GroupController@index')); ?>">Groups</a></li>
				<?php endif; ?>
	          </ul>
	          <ul class="nav navbar-nav navbar-right">
	            <?php if(Sentry::check()): ?>
				<li <?php echo (Request::is('profile') ? 'class="active "' : ''); ?>>
					<a href="<?php echo e(route('sentinel.profile.show')); ?>"><span class="glyphicon glyphicon-home"></span> <?php echo e(Sentry::getUser()->email); ?></a>
				</li>
				<li>
					<a href="<?php echo e(route('sentinel.logout')); ?>">Logout</a>
				</li>
				<?php else: ?>
				<li <?php echo (Request::is('login') ? 'class="active"' : ''); ?>><a href="<?php echo e(route('sentinel.login')); ?>">Login</a></li>
				<li <?php echo (Request::is('users/create') ? 'class="active"' : ''); ?>><a href="<?php echo e(route('sentinel.register.form')); ?>">Register</a></li>
				<?php endif; ?>
	          </ul>
	        </div><!--/.nav-collapse -->
	      </div>
	    </div>
		<!-- ./ navbar -->

		<!-- Container -->
		<div class="container">
			<!-- Notifications -->
			<?php echo $__env->make('Sentinel::layouts/notifications', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<!-- ./ notifications -->

			<!-- Content -->
			<?php echo $__env->yieldContent('content'); ?>
			<!-- ./ content -->
		</div>

		<!-- ./ container -->

		<!-- Javascripts
		================================================== -->
		<script src="<?php echo e(asset('packages/rydurham/sentinel/js/jquery-2.1.3.min.js')); ?>"></script>
		<script src="<?php echo e(asset('packages/rydurham/sentinel/js/bootstrap.min.js')); ?>"></script>
		<script src="<?php echo e(asset('packages/rydurham/sentinel/js/restfulizer.js')); ?>"></script> 
		<!-- Thanks to Zizaco for the Restfulizer script.  http://zizaco.net  -->
	</body>
</html>
